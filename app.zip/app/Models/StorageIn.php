<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StorageIn extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'storage_ins';
    protected $guarded = [];

    /**
     * StorageIn belongs to Barang.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    // public function barang()
    // {
    // 	// belongsTo(RelatedModel, foreignKey = barang_id, keyOnRelatedModel = id)
    // 	return $this->belongsTo('App\Models\Barang', 'barang_kode', 'kode_barang');
    // }

    /**
     * StorageIn belongs to Gudang.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function gudang()
    {
    	// belongsTo(RelatedModel, foreignKey = gudang_id, keyOnRelatedModel = id)
    	return $this->belongsTo('App\Models\Gudang');
    }

    /**
     * StorageIn belongs to User.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
    	// belongsTo(RelatedModel, foreignKey = user_id, keyOnRelatedModel = id)
    	return $this->belongsTo('App\User');
    }

    /**
     * StorageIn has many Storage.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function storage()
    {
    	// hasMany(RelatedModel, foreignKeyOnRelatedModel = storageIn_id, localKey = id)
    	return $this->hasOne('App\Models\Storage', 'storage_masuk_id');
    }

    public function rekapitulasi()
    {
    	return $this->hasMany('App\Models\RekapitulasiPembelian');
    }

    /**
     * StorageIn belongs to PemesananBulky.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function pemesananBulky()
    {
        // belongsTo(RelatedModel, foreignKey = pemesananBulky_id, keyOnRelatedModel = id)
        return $this->belongsTo('App\Models\PemesananBulky', 'pemesanan_bulky_id');
    }

    /**
     * StorageIn belongs to BarangBulky.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function barangBulky()
    {
        // belongsTo(RelatedModel, foreignKey = barangBulky_id, keyOnRelatedModel = id)
        return $this->belongsTo('App\Models\StockBarangBulky', 'barang_bulky_id');
    }

    /**
     * StorageIn belongs to Satuan.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function satuan()
    {
        // belongsTo(RelatedModel, foreignKey = satuan_id, keyOnRelatedModel = id)
        return $this->belongsTo('App\Models\Satuan', 'satuan_id');
    }
}
