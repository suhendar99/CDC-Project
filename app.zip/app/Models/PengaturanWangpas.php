<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PengaturanWangpas extends Model
{
    protected $table = 'pengaturan_wangpas';
    protected $guarded = [];
}
