<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LogTransaksi extends Model
{
    protected $table = 'log_transaksis';
    protected $guarded = [];
}
