<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TransaksiPemasok extends Model
{
    //
}
