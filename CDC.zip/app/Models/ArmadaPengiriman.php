<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ArmadaPengiriman extends Model
{
    protected $table = 'armada_pengirimen';
    protected $guarded = [];
}
