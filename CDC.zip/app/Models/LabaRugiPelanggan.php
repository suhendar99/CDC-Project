<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LabaRugiPelanggan extends Model
{
    protected $table = 'laba_rugi_pelanggans';
    protected $guarded = [];
}
