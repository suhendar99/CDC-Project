<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UiBanner extends Model
{
    protected $table = 'ui_banners';
    protected $guarded = [];
}
