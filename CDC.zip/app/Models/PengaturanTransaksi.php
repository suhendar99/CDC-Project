<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PengaturanTransaksi extends Model
{
    protected $table = 'pengaturan_transaksis';
    protected $guarded = [];
}
