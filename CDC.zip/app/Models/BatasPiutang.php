<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BatasPiutang extends Model
{
    protected $table = 'batas_piutangs';
    protected $guarded = [];
}
