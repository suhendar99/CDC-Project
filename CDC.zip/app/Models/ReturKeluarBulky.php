<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReturKeluarBulky extends Model
{
    //
}
