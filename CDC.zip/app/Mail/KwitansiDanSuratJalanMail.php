<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;


class KwitansiDanSuratJalanMail extends Mailable
{
    use Queueable, SerializesModels;

    public $pdfSJ;
    public $pdfKwitansi;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($pdfSJ, $pdfKwitansi)
    {
        $this->pdfSJ = $pdfSJ;
        $this->pdfKwitansi = $pdfKwitansi;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('app.mail.send_sj_dan_kwitansi')
        ->attachData($this->pdfSJ->output(), "surat-jalan.pdf", [
            'mime' => 'application/pdf',
        ])
        ->attachData($this->pdfKwitansi->output(), "kwitansi.pdf", [
            'mime' => 'application/pdf',
        ]);;
    }
}
