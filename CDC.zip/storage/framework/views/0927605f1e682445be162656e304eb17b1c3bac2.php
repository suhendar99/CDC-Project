<?php
    $icon = 'receipt_long';
    $pageTitle = 'Preview Purchase Order';
    $preview = true;
?>



<?php $__env->startSection('content'); ?>


<div class="row valign-center mb-2">
    <div class="col-md-12 col-sm-12 valign-center py-2">
        <i class="material-icons md-48 text-my-warning"><?php echo e($icon); ?></i>
        <div>
          <h4 class="mt-1 mb-0"><?php echo e($pageTitle); ?></h4>
          <div class="valign-center breadcumb">
            <a href="#" class="text-14">Dashboard</a>
            <i class="material-icons md-14 px-2">keyboard_arrow_right</i>
            <a href="#" class="text-14">Data Purchase Order</a>
            <i class="material-icons md-14 px-2">keyboard_arrow_right</i>
            <a href="#" class="text-14"><?php echo e($pageTitle); ?></a>
          </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card my-3">
                <div class="card-header">
                    <h4 class="card-title float-left">Preview Surat Purchase Order</h4>
                    <div class="float-right">
                        <a href="<?php echo e(route('po.print',$data->id)); ?>" target="_blank" class="btn bg-my-success">
                            <div class="d-flex valign-center">
                                <i class="material-icons md-18 p-0 mr-1">download</i>Download
                            </div>
                        </a>
                        <?php if(Auth::user()->pemasok_id != null): ?>
                            <a href="<?php echo e(route('po.masuk.pemasok')); ?>" class="btn bg-my-primary">Kembali</a>
                        <?php elseif(Auth::user()->pengurus_gudang_id != null): ?>
                            <a href="<?php echo e(route('po.index')); ?>" class="btn bg-my-primary">Kembali</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card my-3">
                <div class="card-body">
                    <div class="print-page border-all">
                        <?php echo $__env->make('app.transaksi.gudang.po.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CDC\resources\views/app/transaksi/pemesanan-barang/konfirmasiPo.blade.php ENDPATH**/ ?>