<?php
        $icon = 'storage';
        $pageTitle = 'Data Gudang';
?>


<?php $__env->startSection('content'); ?>
<div class="row valign-center mb-2">
    <div class="col-md-8 col-sm-12 valign-center py-2">
        <i class="material-icons md-48 text-my-warning"><?php echo e($icon); ?></i>
        <div>
          <h4 class="mt-1 mb-0"><?php echo e($pageTitle); ?></h4>
          <div class="valign-center breadcumb">
            <a href="#" class="text-14">Dashboard</a>
            <i class="material-icons md-14 px-2">keyboard_arrow_right</i>
            <a href="#" class="text-14">Data Gudang</a>
          </div>
        </div>
    </div>
    
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12 mb-3">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="float-left">
                                <form action="<?php echo e(route('gudang.search')); ?>" method="post" style="width: 100%;">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group">
                                        <input type="text" name="nama" class=" form-control" placeholder=" Cari gudang ..." aria-label="Cari gudang..." aria-describedby="basic-addon1">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-outline-secondary">search</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="float-right">
                                <a href="<?php echo e(route('gudang.create')); ?>" class="btn btn-primary btn-sm">Tambah Data Gudang</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="row">
                <?php if(count($data) > 0): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gudang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-4">
                    <div class="card">
                        <img src="<?php echo e(asset($gudang->foto)); ?>" alt="Card Image" class="card-img-top" style="height: 150px;">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="float-left">
                                        <h5><?php echo e($gudang->nama); ?></h5>
                                        <span><?php echo e($gudang->nomor_gudang); ?></span>
                                    </div>
                                    <div class="float-right">
                                        <div class="dropdown">
                                            <a href="#" title="Menu" class="dropdown-toggle p-2" id="dropmenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu" aria-labelledby="dropmenu">
                                                <a href="<?php echo e(route('gudang.edit', $gudang->id)); ?>" class="dropdown-item">Edit</a>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal" onclick="detail(<?php echo e($gudang->id); ?>)" data-id="<?php echo e($gudang->id); ?>">Detail</a>
                                                <a href="<?php echo e(route('rak.index', $gudang->id)); ?>" class="dropdown-item">Rak Gudang</a>
                                                <a href="#" class="dropdown-item" onclick="sweet(<?php echo e($gudang->id); ?>)">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Jumlah Rak: <?php echo e($gudang->rak_count); ?> <a href="<?php echo e(route('rak.index', $gudang->id)); ?>" class="text-primary">Detail</a></li>
                            <li class="list-group-item">Hari Kerja: <?php echo e($gudang->hari); ?></li>
                            <li class="list-group-item" style="border-bottom: 1px solid rgba(0, 0, 0, 0.125);"><?php echo e($gudang->jam_buka); ?> - <?php echo e($gudang->jam_tutup); ?></li>
                        </ul>
                        <div class="card-body" style="border-bottom: 5px solid #ffa723;">
                            <h6>Alamat</h5>
                            <p class="card-text"><?php echo e($gudang->alamat); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="col-12">
                    <div class="footer-copyright text-center pt-4 text-dark fixed">
                        ~ Tidak Ada Data Gudang ~
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-12">
            <?php echo e($data->links()); ?>

        </div>
    </div>
</div>
<form action="" id="formDelete" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Detail Data Gudang</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
              <div class="col-md-12 mb-3">
                  <h3 id="nama"></h3>
              </div>
          </div>
          <div class="row">
            <div class="col-12 text-center">
                <span>Foto Gudang</span><br>
                <div id="foto" class="my-4"></div>
            </div>
              <div class="col-12">
                  <table class="table">
                      <tbody>
                        <tr>
                            <th scope="row">Nama Gudang</th>
                            <td class="nama"></td>
                        </tr>
                        <tr>
                          <th scope="row">Kontak</th>
                          <td class="kontak"></td>
                        </tr>
                        <tr>
                          <th scope="row">hari Kerja</th>
                          <td class="hari"></td>
                        </tr>
                        <tr>
                          <th scope="row">Jam Buka</th>
                          <td class="buka"></td>
                        </tr>
                        <tr>
                          <th scope="row">Jam Tutup</th>
                          <td class="tutup"></td>
                        </tr>
                        <tr>
                          <th scope="row">Kapasitas</th>
                          <td class="kapasitas"></td>
                        </tr>
                        <tr>
                          <th scope="row">Provinsi</th>
                          <td class="provinsi"></td>
                        </tr>
                        <tr>
                          <th scope="row">Kabupaten</th>
                          <td class="kabupaten"></td>
                        </tr>
                        <tr>
                          <th scope="row">Kecamatan</th>
                          <td class="kecamatan"></td>
                        </tr>
                        <tr>
                          <th scope="row">Desa</th>
                          <td class="desa"></td>
                        </tr>
                        <tr>
                          <th scope="row">Alamat</th>
                          <td class="alamat"></td>
                        </tr>
                      </tbody>
                  </table>
              </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>

<script type="text/javascript">
    // let table = $('#data_table').DataTable({
    //         processing : true,
    //         serverSide : true,
    //         responsive: true,
    //         ordering : false,
    //         pageLength : 10,
    //         ajax : "",
    //         columns : [
    //             {data : 'DT_RowIndex', name: 'DT_RowIndex', searchable:false,orderable:false},
    //             {data : 'nama', name: 'nama'},
    //             {data : 'alamat', render:function(data,a,b,c){
    //                     return (data == null || data == "") ? "Mohon Lengkapi Data !" : data;
    //                 }
    //             },
    //             {data : 'kontak', render:function(data,a,b,c){
    //                     return (data == null || data == "") ? "Mohon Lengkapi Data !" : data;
    //                 }
    //             },
    //             {data : 'hari', name: 'hari'},
    //             {data : 'action', name: 'action'}
    //         ]
    //     });

        function detail(id){
            $('#foto').text("Mendapatkan Data.......")
            $('.nama').text("Mendapatkan Data.......")
            $('.kontak').text("Mendapatkan Data.......")
            $('.alamat').text("Mendapatkan Data.......")
            $('.hari').text("Mendapatkan Data.......")
            $('.buka').text("Mendapatkan Data.......")
            $('.tutup').text("Mendapatkan Data.......")
            $('.kapasitas').text("Mendapatkan Data.......")
            $('.provinsi').text("Mendapatkan Data.......")
            $('.kabupaten').text("Mendapatkan Data.......")
            $('.kecamatan').text("Mendapatkan Data.......")
            $('.desa').text("Mendapatkan Data.......")
            $.ajax({
                url: "/api/v1/getGudang/"+id,
                method: "GET",
                contentType: false,
                cache: false,
                processData: false,
                success: (response)=>{
                    console.log(response.data)
                    $.each(response.data, function (a, b) {
                        // $('#btn-edit').attr('href', '/v1/saranaPrasaranaUPTD/'+b.id+'/edit').removeClass('btn-progress');
                        // $('#btn-delete').attr('onclick', 'sweet('+b.id+')').removeClass('btn-progress');
                            $('.nama').text(b.nama)
                            $('.kontak').text(b.kontak)
                            $('.alamat').text(b.alamat)
                            $('.hari').text(b.hari)
                            $('.buka').text(b.jam_buka)
                            $('.tutup').text(b.jam_tutup)
                            $('.kapasitas').text(b.kapasitas+' \u33A1')
                            $('.provinsi').text(b.desa.kecamatan.kabupaten.provinsi.nama)
                            $('.kabupaten').text(b.desa.kecamatan.kabupaten.nama)
                            $('.kecamatan').text(b.desa.kecamatan.nama)
                            $('.desa').text(b.desa.nama)
                        if (b.foto == null) {
                            $("#foto").text('- Tidak Ada Foto Barang -');
                        }else{
                            $("#foto").html(`<img class="foto" style="width:100%; height:300px;" src="<?php echo e(asset('${b.foto}')); ?>">`);
                        }
                    });
                },
                error: (xhr)=>{
                    let res = xhr.responseJSON;
                    console.log(res)
                }
            });
        }
        function sweet(id){
            const formDelete = document.getElementById('formDelete')
            formDelete.action = '/v1/gudang/'+id

            const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            })
            Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    formDelete.submit();
                    Toast.fire({
                        icon: 'success',
                        title: 'Your file has been deleted,wait a minute !'
                    })
                    // Swal.fire(
                    // 'Deleted!',
                    // 'Your file has been deleted.',
                    // 'success'
                    // )
                }
            })
        }
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CDC\resources\views/app/data-master/gudang/index.blade.php ENDPATH**/ ?>