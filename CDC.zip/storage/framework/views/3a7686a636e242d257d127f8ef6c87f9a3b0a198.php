<?php
    // dd($uptd);
    // setlocale(LC_MONETARY, 'id_ID');
?>
<style>
    table {
        border: 1px solid #000;
    }
    tr th{
        border: 1px solid #000000;
    }
</style>
<table border="1 solid">
    <thead>
    <tr>
        <th style="border: 1px solid black">No</th>
        <th style="border: 1px solid black">Waktu Barang Masuk</th>
        <th style="border: 1px solid black">Kode Barang</th>
        <th style="border: 1px solid black">Nama Barang</th>
        <th style="border: 1px solid black">Nama Gudang</th>
        <th style="border: 1px solid black">Kode Barang Masuk</th>
        <th style="border: 1px solid black">Jumlah</th>
    </tr>
    </thead>
    <tbody>
        <?php $no = 1 ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="border: 1px solid black"><?php echo e($no++); ?></td>
                <td style="border: 1px solid black"><?php echo e($a->waktu); ?></td>
                <td style="border: 1px solid black"><?php echo e($a->barang->kode_barang); ?></td>
                <td style="border: 1px solid black"><?php echo e($a->barang->nama_barang); ?></td>
                <td style="border: 1px solid black"><?php echo e($a->gudang->nama); ?></td>
                <td style="border: 1px solid black"><?php echo e($a->kode); ?></td>
                <td style="border: 1px solid black"><?php echo e($a->jumlah); ?> <?php echo e($a->satuan); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\CDC\resources\views/app/laporan/pengurus-gudang/barang-keluar/excel.blade.php ENDPATH**/ ?>