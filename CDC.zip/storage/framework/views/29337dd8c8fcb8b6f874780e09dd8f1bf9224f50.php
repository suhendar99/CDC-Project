<table width="100%" style="margin-bottom: -10px; " id="customers">
    <thead>
        <tr>
            <th rowspan="2" style="text-align:center;font-size:11px;border: 1px solid #475F7B; padding: 30px;"><center>No</center></th>
            <th rowspan="2" style="text-align:center;font-size:11px;border: 1px solid #475F7B;">Kode PO</th>
            <th rowspan="2" style="text-align:center;font-size:11px;border: 1px solid #475F7B;">Gudang</th>
            <th rowspan="2" style="text-align:center;font-size:11px;border: 1px solid #475F7B;">Penerima PO</th>
            <th rowspan="2" style="text-align:center;font-size:11px;border: 1px solid #475F7B;">Alamat peneriam</th>
            <th colspan="5" style="text-align:center;font-size:11px;border: 1px solid #475F7B;">Item</th>
        </tr>
        <tr>
            <th style="color: black; text-align:center;font-size:11px;border: 1px solid #475F7B;">Nama Barang</th>
            <th style="color: black; text-align:center;font-size:11px;border: 1px solid #475F7B;">Jumlah Barang</th>
            <th style="color: black; text-align:center;font-size:11px;border: 1px solid #475F7B;">Harga Barang</th>
            <th style="color: black; text-align:center;font-size:11px;border: 1px solid #475F7B;">Diskon</th>
            <th style="color: black; text-align:center;font-size:11px;border: 1px solid #475F7B;">Pajak</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;" rowspan="<?php echo e($value->po_item->count()); ?>"><?php echo e($key+1); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;" rowspan="<?php echo e($value->po_item->count()); ?>"><?php echo e($value->kode_po); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;" rowspan="<?php echo e($value->po_item->count()); ?>"><?php echo e($value->gudang->nama); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;" rowspan="<?php echo e($value->po_item->count()); ?>"><?php echo e($value->penerima_po); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;" rowspan="<?php echo e($value->po_item->count()); ?>"><?php echo e($value->alamat_penerima); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;"><?php echo e($value->po_item[0]->nama_barang); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;"><?php echo e($value->po_item[0]->jumlah); ?> <?php echo e($value->po_item[0]->satuan); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;">Rp <?php echo e(number_format($value->po_item[0]->harga)); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;"><?php echo e($value->po_item[0]->diskon); ?> %</td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;"><?php echo e($value->po_item[0]->pajak); ?> %</td>
        </tr>
        <?php if($value->po_item->count() > 1): ?>
        <?php $__currentLoopData = $value->po_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key > 0): ?>
        <tr>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;"><?php echo e($i->nama_barang); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;"><?php echo e($i->jumlah); ?> <?php echo e($i->satuan); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;">Rp <?php echo e(number_format($i->harga)); ?></td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;"><?php echo e($i->diskon); ?> %</td>
            <td style="text-align:center;font-size:11px;border: 1px solid #475F7B;"><?php echo e($i->pajak); ?> %</td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\CDC\resources\views/app/laporan/pengurus-gudang/po/excel.blade.php ENDPATH**/ ?>