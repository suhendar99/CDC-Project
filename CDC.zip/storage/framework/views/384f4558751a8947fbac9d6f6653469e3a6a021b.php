<?php
    $date = Carbon\Carbon::now()->translatedFormat(' d F Y');
    $title = 'PDF Data Rekapitulasi Penjualan'
?>

<!DOCTYPE html>
<html>
<head>
	<title><?php echo e($title); ?></title>
	<style>
		#customers {
		font-family: 'Poppins', sans-serif;
		border-collapse: collapse;
		width: 100%;
		}
		#customers td, #customers th {
		border: 1px solid #ddd;
		padding: 8px;
		}
		#customers tr:nth-child(even){background-color: #ddd;}
		#customers tr:hover {background-color: #ddd;}
		#customers thead {
		padding-top: 7px;
		padding-bottom: 7px;
		text-align: left;
		background-color: #8a8a8a;
		color: white;
		}
		*{
			font-family:sans-serif;
		}
		table {
			width: 100%;
			padding: 5px;
		}
		table, th, tr, td {
			border: 1px black;
            text-align: center;
        }
		#header,
		#footer {
		  position: fixed;
		  left: 0;
			right: 0;
			color: #aaa;
			font-size: 0.7em;
		}
		#header {
		  top: 0;
			border-bottom: 0.1pt solid #aaa;
		}
		#footer {
		  bottom: 0;
		  border-top: 0.1pt solid #aaa;
		}
		.page-number:before {
		  content: "Page " counter(page);
		}
	</style>
</head>
<body>
	
	<h3 style=" margin-top: 30px; margin-right:20px;">
		
	</h3>

	<div class="container">
	<style type="text/css">
		table tr td{
            text-align: center;
            font-size: 15px;
		}
		table tr th{
            text-align: center;
            font-size: 15px;
		}
		table {
		  border-collapse: collapse;
		  width: 100%;
		}
		th, td {
		  text-align: left;
		  padding: 8px;
        }
        img {
            height: 60px;
            width: auto;
        }
        .left {
            height: auto;
            width: 50px;
        }
        .text {
            padding: 1px !important;
            margin-left: 40px;
            text-align: center ;
            margin-top: 20px;
            height: auto;
        }
        table, td{
            background-color: #ffffff;
            /* padding: 2px; */
        }
        table td .text{
            background-color: #ffffff;
            padding: 2px;
        }
		tr:nth-child(even) {background-color: #f2f2f2;}
	</style>
        <center>
            <h3><?php echo e($title); ?></h3>
        </center>
	<table style="margin-bottom:-10px;">
		
	</table>
    <table width="100%" style="margin-bottom: -10px; " id="customers">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Pembelian</th>
                <th>No Pembelian</th>
                <th>No Kwitansi</th>
                <th>No Surat Jalan</th>
                <th>Nama Penjual</th>
                <th>Nama Barang</th>
                <th>Jumlah Barang</th>
                <th>Harga Barang</th>
                <th>Total Harga Barang</th>
        </thead>
        <tbody>
            <?php $no = 1 ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e(date('d F Y',strtotime($a->tanggal_pembelian))); ?></td>
                    <td><?php echo e($a->no_pembelian); ?></td>
                    <td><?php echo e($a->no_kwitansi); ?></td>
                    <td><?php echo e($a->no_surat_jalan); ?></td>
                    <td><?php echo e($a->nama_penjual); ?></td>
                    <td><?php echo e($a->barang); ?></td>
                    <td><?php echo e($a->jumlah); ?> <?php echo e($a->satuan); ?></td>
                    <td><?php echo e($a->harga); ?></td>
                    <td><?php echo e($a->total); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
	</table>

	
	<div id="footer">
	  <div class="page-number"></div>
	</div>

<script>
</script>
</body>
</html>
<?php /**PATH C:\laragon\www\CDC\resources\views/app/transaksi/rekapitulasi/pembelian/pdf.blade.php ENDPATH**/ ?>