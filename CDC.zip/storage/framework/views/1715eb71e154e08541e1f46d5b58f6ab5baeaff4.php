<div id="category">
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-6 pl-2 pr-2 pb-4">
            <div class="card" style="height: auto;">
                <div class="card-body d-flex justify-content-center">
                    <a href="<?php echo e(route('cari.kategori',$c->id)); ?>"></a>
                    <center>
                            <i class="material-icons text-my-warning md-48"><?php echo e($c['icon']); ?></i><br>
                            <span><?php echo e($c['nama']); ?></span>
                    </center>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 pl-2 pr-2 pb-4">
            <p class="not-found text-center">Tidak Ada Kategori</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\CDC\resources\views/layouts/shop/category.blade.php ENDPATH**/ ?>