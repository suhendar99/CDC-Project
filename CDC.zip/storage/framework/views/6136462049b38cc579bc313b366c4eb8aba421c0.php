<?php
    $icon = 'receipt_long';
    $pageTitle = 'Pemesanan';
    $nosidebar = true;
?>



<?php $__env->startSection('content'); ?>


<div class="row valign-center mb-2">
    <div class="col-md-12 col-sm-12 valign-center py-2">
        <i class="material-icons md-48 text-my-warning"><?php echo e($icon); ?></i>
        <div>
          <h4 class="mt-1 mb-0"><?php echo e($pageTitle); ?></h4>
          <div class="valign-center breadcumb">
            <a href="#" class="text-14">Dashboard</a>
            <i class="material-icons md-14 px-2">keyboard_arrow_right</i>
            <a href="#" class="text-14"><?php echo e($pageTitle); ?></a>
          </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('po.update',$data->id)); ?>" name="keranjang" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Pemesanan Barang</h4>
                            </div>
                            <input type="hidden" name="penerima_po" id="penerima" value="<?php echo e($data->pemasok->nama); ?>">
                            <input type="hidden" name="nama_pemesan" id="pemesan" value="<?php echo e(Auth::user()->pengurusGudang->nama); ?>">
                            <input type="hidden" name="pengurus_gudang_id" value="<?php echo e(Auth::user()->pengurus_gudang_id); ?>">
                            <input type="hidden" name="alamat" value="<?php echo e(Auth::user()->pengurusGudang->alamat); ?>">
                            <input type="hidden" name="telepon" value="<?php echo e(Auth::user()->pengurusGudang->telepon); ?>">
                            <input type="hidden" name="pemasok_id" value="<?php echo e($data->pemasok->id); ?>">
                            <input type="hidden" name="harga" id="harga" value="<?php echo e($data->harga_barang); ?>">
                            <input type="hidden" name="nama_barang" value="<?php echo e($data->nama_barang); ?>">
                            <input type="hidden" name="satuan" value="<?php echo e($data->satuan); ?>">
                            <input type="hidden" name="barangKode" value="<?php echo e($data->kode_barang); ?>">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-3">
                                        <h6>Nama Barang</h6>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="float-left">:</div>
                                        <div class="float-left ml-2" id="nama"><h6><?php echo e($data->nama_barang); ?></h6></div>
                                    </div>
                                    <div class="col-md-3">
                                        <h6>Harga Barang</h6>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="float-left">:</div>
                                        <div class="float-left ml-2" id="harga"><h6>Rp. <?php echo e(number_format($data->harga_barang,0,',','.')); ?></h6></div>
                                    </div>
                                    <div class="col-md-3">
                                        <h6>Dari Pemasok</h6>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="float-left">:</div>
                                        <div class="float-left ml-2" id="penjual"><h6><?php echo e($data->pemasok->nama); ?></h6></div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Jumlah Barang <small class="text-success">*Harus diisi</small></label>
                                            <div class="input-group">
                                                <input type="number" id="jumlah" class="form-control <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah" value="<?php echo e(old('jumlah')); ?>" aria-describedby="satuanAppend">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="satuanAppend"><?php echo e($data->satuan); ?></span>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Pembayaran <small class="text-success">*Harus diisi</small></label>
                                        <select id="selectPembayaran" class="form-control <?php $__errorArgs = ['pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pembayaran"  >
                                            <option value="now">Bayar Sekarang</option>
                                            <option value="later">Bayar Nanti</option>
                                        </select>
                                        <?php $__errorArgs = ['pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div id="pilihMetode" class="col-md-4 ">
                                        <label>Metode Pembayaran <small class="text-success">*Harus diisi</small></label>
                                        <select class="form-control <?php $__errorArgs = ['metode_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="metode_pembayaran"  >
                                            <option value="">-- Pilih Metode --</option>
                                            <option value="transfer">Transfer Ke (Rekening Penjual)</option>
                                            <option value="wangpas">Wangpas</option>
                                            <option value="bayar di tempat">Bayar di tempat</option>
                                        </select>
                                        <?php $__errorArgs = ['metode_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <label>Nomor Telepon <small class="text-success">*Harus diisi</small></label>
                                            <input id="telepon" type="number" min="1" class="form-control <?php $__errorArgs = ['telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telepon" value="<?php echo e(Auth::user()->pengurusGudang->telepon); ?>" >
                                            <?php $__errorArgs = ['telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Alamat<small class="text-success">*Harus diisi</small></label>
                                            <textarea id="alamat" class="form-control <?php $__errorArgs = ['alamat_pemesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat_pemesan" value="<?php echo e(Auth::user()->pengurusGudang->alamat); ?>"><?php echo e(Auth::user()->pengurusGudang->alamat); ?></textarea>
                                            <?php $__errorArgs = ['alamat_pemesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 mt-2">
                        <button type="submit" class="btn btn-sm bg-my-primary btn-block">Pesan Langsung</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    $('#postKeranjang').click(function(){
        $('form[name=keranjang]').attr('action',"<?php echo e(route('keranjang.store',$id)); ?>");
        $('form[name=keranjang]').submit();
    })

    $('#selectPembayaran').change(function(){
        pembayaran = $(this).val()
        if (pembayaran == 'now') {
            $('#pilihMetode').removeClass('d-none')
        } else {
            $('#pilihMetode').addClass('d-none')
        }
    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CDC\resources\views/app/transaksi/gudang/po/pesanan.blade.php ENDPATH**/ ?>