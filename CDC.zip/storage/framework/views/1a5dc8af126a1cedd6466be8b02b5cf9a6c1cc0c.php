<div id="navbar">
	<nav class="navbar navbar-light bg-light shadow px-4 w-100 fixed">
		<button type="button" id="categoryCollapse" class="btn btn-sm btn-transparent mr-auto">
        <i class="material-icons md-24 text-my-primary">dehaze</i>
    </button>
		<a class="navbar-brand pl-2" href="/">
	    <img src="<?php echo e(asset('images/logo-cdc.png')); ?>" width="50" class="d-inline-block align-top" alt="">
	    <b class="text-24 text-my-primary">Shop</b>
      </a>
        <?php if(auth()->guard()->guest()): ?>
            <a class="ml-auto pr-2" href="<?php echo e(route('login')); ?>">Login</a>
        <?php else: ?>
        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
            <?php echo e(isset(Auth::user()->pelanggan_id) ? Auth::user()->pelanggan->nama :  (isset(Auth::user()->pengurus_gudang_id) ? Auth::user()->pengurusGudang->nama :(isset(Auth::user()->bank_id) ? Auth::user()->bank->nama : (isset(Auth::user()->pemasok_id) ? Auth::user()->pemasok->nama : Auth::user()->name)))); ?>

        </a>

        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
            <?php if(Auth::user()->pengurus_gudang_id != null): ?>
                <a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">
                    <?php echo e(__('Dashboard')); ?>

                </a>
            <?php endif; ?>
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
        <?php endif; ?>
    </nav>
    <?php if(session()->has('sukses')): ?>
    <script>
        alert("<?php echo e(session()->get('sukses')); ?>");
    </script>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\CDC\resources\views/layouts/shop/navbar.blade.php ENDPATH**/ ?>