@php
        $icon = 'storage';
        $pageTitle = 'Data Pemesanan Masuk';
@endphp
@extends('layouts.dashboard.header')

@section('content')
<div class="row valign-center mb-2">
    <div class="col-md-8 col-sm-12 valign-center py-2">
        <i class="material-icons md-48 text-my-warning">{{$icon}}</i>
        <div>
          <h4 class="mt-1 mb-0">{{$pageTitle}}</h4>
          <div class="valign-center breadcumb">
            <a href="#" class="text-14">Dashboard</a>
            <i class="material-icons md-14 px-2">keyboard_arrow_right</i>
            <a href="#" class="text-14">Data Transaksi</a>
            <i class="material-icons md-14 px-2">keyboard_arrow_right</i>
            <a href="#" class="text-14">Data Pemesanan Masuk</a>
          </div>
        </div>
    </div>
    {{-- <div class="col-md-4 col-sm-12 valign-center py-2">
        @include('layouts.dashboard.search')
    </div> --}}
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="float-left">
                                <h5></h5>
                            </div>
                        </div>
                        <div class="col-md-6">
                            {{-- <div class="float-right">
                                <a href="{{route('pemesanan.create')}}" class="btn btn-primary btn-sm">Tambah Pesanan</a>
                            </div> --}}
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <table id="data_table" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Kode Barang</th>
                                <th>Nama Barang</th>
                                <th>Jumlah Barang Dibeli</th>
                                <th>Harga</th>
                                <th>Tanggal Pemesanan</th>
                                {{-- <th>Action</th> --}}
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<form action="" id="formDelete" method="POST">
    @csrf
    @method('DELETE')
</form>
@push('script')
    <script>
        let table = $('#data_table').DataTable({
            processing : true,
            serverSide : true,
            responsive: true,
            ordering : false,
            pageLength : 10,
            ajax : "{{ route('pemesanan.index') }}",
            columns : [
                // {data : 'DT_RowIndex', name: 'DT_RowIndex', searchable:false,orderable:false},
                {data : 'barang.kode_barang', name: 'kode_barang'},
                {data : 'barang.nama_barang', name: 'barang'},
                {data : function(data, a, b, c) {
                    return data.jumlah_barang+' '+data.satuan;
                }, name: 'jumlah'},
                {data : 'harga', render:function(data,a,b,c){
                        return 'Rp. '+ (data.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,"));
                    }
                },
                {data : 'pesanan.tanggal_pemesanan', name: 'tanggal_pemesanan'}
                // {
                //   data : 'pengurus.gudang', render:function(data,a,b,c){
                //         return data[0].nama;
                //   }
                // },
                // {data : 'action', name: 'action'}
            ],
            order: [[2, 'asc']],
            rowGroup: {
                dataSrc: 'pesanan.kode',
                startRender: function(rows, group){
                    console.log(rows.data()[0].pesanan);
                    if (rows.data()[0].pesanan.storage_out.length < 1) {
                        return `<div class="float-left">Nomor Pemesanan: ${rows.data()[0].pesanan.nomor_pemesanan} <br> Nama Pemesan: ${rows.data()[0].pesanan.nama_pemesan}</div><div class="float-right"><a href="/v1/storage/out/create?pemesanan=${rows.data()[0].pemesanan_id}" class="btn btn-info btn-sm">Proses Pesanan</a>&nbsp;<a href="#" class="btn btn-danger btn-sm" style="" onclick="sweet(${rows.data()[0].pemesanan_id})">Hapus</a></div>`;
                    } else {
                        return `<div class="float-left">Nomor Pemesanan: ${rows.data()[0].pesanan.nomor_pemesanan} <br> Nama Pemesan: ${rows.data()[0].pesanan.nama_pemesan}</div><div class="float-right"><span class="badge badge-success py-2 px-1" style="font-size: .7rem">Pemesanan Selesai Diproses</span>&nbsp;<a href="#" class="btn btn-danger btn-sm" style="" onclick="sweet(${rows.data()[0].pemesanan_id})">Hapus</a></div>`;
                    }
                },
                endRender: function(rows, group){
                    // console.log(rows.data().length);
                    return 'Jumlah Barang yang dipesan: '+rows.data().length;
                },
            }
        });

        function detail(id){
            $('.namaBank').text('LOADING...')
            $('.namaAkun').text('LOADING...')
            $('.username').text('LOADING...')
            $('.email').text('LOADING...')
            $('.tahun').text('LOADING...')
            $('.telepon').text('LOADING...')
            $('.alamat').text('LOADING...')

            $.ajax({
                url: "/api/v1/detail/bank/"+id,
                method: "GET",
                contentType: false,
                cache: false,
                processData: false,
                success: (response)=>{
                    // console.log(response.data)
                    let bank = response.data;

                    $('.namaBank').text(bank.nama)
                    $('.namaAkun').text(bank.user[0].name)
                    $('.username').text(bank.user[0].username)
                    $('.email').text(bank.user[0].email)
                    $('.tahun').text(bank.tahun_berdiri)
                    $('.telepon').text(bank.telepon)
                    $('.alamat').text(bank.alamat)

                    if (bank.foto == null) {
                        $("#foto").text('- Tidak Ada Foto Bank -');
                    }else{
                        $("#foto").html(`<img class="foto" style="width:100%; height:300px;" src="{{asset('${bank.foto}')}}">`);
                    }
                },
                error: (xhr)=>{
                    let res = xhr.responseJSON;
                    console.log(res)
                }
            });
        }
        function sweet(id){
            const formDelete = document.getElementById('formDelete')
            formDelete.action = '/v1/pemesanan/'+id

            const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            })
            Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    formDelete.submit();
                    Toast.fire({
                        icon: 'success',
                        title: 'Your file has been deleted,wait a minute !'
                    })
                    // Swal.fire(
                    // 'Deleted!',
                    // 'Your file has been deleted.',
                    // 'success'
                    // )
                }
            })
        }
    </script>
@endpush
@endsection
