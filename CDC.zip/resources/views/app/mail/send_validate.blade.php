<div>
	<h3>Verifikasi Pemesanan</h3>
	<p>Pesanan anda: {{ $data['nomor_pemesanan'] }} dari {{ $data['penjual'] }} telah diverifikasi oleh penjual. Pesanan anda sedang diproses.</p>
	<p>{{ $data['waktu'] }}</p>
</div>