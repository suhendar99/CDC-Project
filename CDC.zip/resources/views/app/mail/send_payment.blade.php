<body>
	<p>Nomor Pemesanan: {{ $pesanan->nomor_pemesanan }}</p>
	<p>Nama Pemesan: {{ $pesanan->nama_pemesan }}</p>
	
	Here the payment:</p>

</body>