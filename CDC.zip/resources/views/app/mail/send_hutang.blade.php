<div>
	<h3>Pemesanan Menggunakan Metode Bayar Nanti</h3>
	<p>Pesanan dengan nomor : {{ $nomor_pemesanan }} melakukan pemesanan dengan metode bayar nanti.</p>
</div>