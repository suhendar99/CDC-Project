<div>
	<p>Halo, kami mengirimkan anda password untuk CDC ke E-mail ini.</p>
	<h3>{{ $password }}</h3>
	<p>Mohon segera ubah password sesuai yang anda inginkan.</p>
	<a href="{{ asset('') }}">CDC</a>
</div>